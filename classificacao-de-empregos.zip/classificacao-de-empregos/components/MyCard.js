import React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';
import { Card } from 'react-native-paper';

export default function MyCard({ title, image, text }) {
  return (
    <Card style={styles.card}>
      <View style={styles.container}>
        {image && (
          <Image 
            style={styles.logo} 
            source={{ uri: image }} 
            resizeMode="cover"
          />
        )}
        <Text style={styles.title}>{title || "Título do Card"}</Text>
        <Text style={styles.text}>{text || "Descrição do card"}</Text>
      </View>
    </Card>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    alignItems: 'center',
  },
  card: {
    marginVertical: 8,
    borderRadius: 10,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
  },
  text: {
    fontSize: 14,
    textAlign: 'center',
    color: '#666',
  },
  logo: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 16,
  }
});
