import React, { useState } from 'react';
import { Text, View, StyleSheet, Image, ScrollView, Button, TextInput } from 'react-native';
import { Card } from 'react-native-paper';
import MyCard from './components/MyCard';

export default function App() {
  // Define the alert function correctly
  const _onPressButton = () => {
    alert("usuario liberado!");
  };

  const [text, setText] = useState(""); // Fixed typo here

  const jobs = [
    { title: "Job 1", image: "image1.jpg", text: "Description of Job 1" },
    { title: "Job 2", image: "image2.jpg", text: "Description of Job 2" },
    { title: "Job 3", image: "image3.jpg", text: "Description of Job 3" }
  ];

  return (
    <ScrollView contentContainerStyle={styles.scrollContainer}>
      <Text style={styles.title}>Classificação de Empregos</Text>
      <Card style={styles.card}>
        <TextInput 
          placeholder="Informe o numero"
          onChangeText={setText} // More concise
          value={text}
        />
      </Card>

      <View style={styles.container}>
        <Image
          source={{
            uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQr6hNvv43GvoYqJZHVrTs1ySR-1Y6iAy5hJQ&s',
          }}
          style={styles.photo}
        />
        
        <Text style={styles.title}>Quais são as vagas de emprego?</Text>

        <Card style={styles.card}>
          <MyCard />
          <Text style={styles.paragraph1}>Empregos Formais</Text>
          <Text style={styles.paragraph2}>
            Trabalho Formal ou Assalariado: Vínculo empregatício com a empresa, regido pela Consolidação das Leis do Trabalho (CLT), com direitos como férias remuneradas, 13º salário e benefícios.
          </Text>
          <Button onPress={_onPressButton} title="Clique Aqui!" />
        </Card>

        <Card style={styles.card}>
          {jobs.map((job, index) => (
            <MyCard
              key={index}
              title={job.title}
              image={job.image}
              text={job.text}
            />
          ))}
        </Card>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scrollContainer: {
    paddingBottom: 20,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph1: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  paragraph2: {
    margin: 24,
    fontSize: 14,
    textAlign: 'center',
  },
  title: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  photo: {
    width: '100%',
    height: 200,
    resizeMode: 'cover',
  },
  card: {
    margin: 24,
    padding: 24,
    backgroundColor: '#fff',
    borderRadius: 10,
    elevation: 3, // Adds shadow for Android
    shadowColor: '#000', // Adds shadow for iOS
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
});



