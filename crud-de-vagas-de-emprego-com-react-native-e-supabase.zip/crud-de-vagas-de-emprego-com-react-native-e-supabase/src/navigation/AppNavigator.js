// src/navigation/AppNavigator.js
import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import { MaterialIcons } from '@expo/vector-icons';

import HomeScreen from '../screens/HomeScreen';
import JobListScreen from '../screens/JobListScreen';
import AddJobScreen from '../screens/AddJobScreen';
import EditJobScreen from '../screens/EditJobScreen';
import JobDetailScreen from '../screens/JobDetailScreen';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

function JobStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: '#6200ee',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }}
    >
      <Stack.Screen 
        name="JobList" 
        component={JobListScreen} 
        options={{ title: 'Lista de Vagas' }}
      />
      <Stack.Screen 
        name="AddJob" 
        component={AddJobScreen} 
        options={{ title: 'Adicionar Vaga' }}
      />
      <Stack.Screen 
        name="EditJob" 
        component={EditJobScreen} 
        options={{ title: 'Editar Vaga' }}
      />
      <Stack.Screen 
        name="JobDetail" 
        component={JobDetailScreen} 
        options={{ title: 'Detalhes da Vaga' }}
      />
    </Stack.Navigator>
  );
}

function AppNavigator() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ color, size }) => {
            let iconName;

            if (route.name === 'Home') {
              iconName = 'home';
            } else if (route.name === 'Jobs') {
              iconName = 'work';
            }

            return <MaterialIcons name={iconName} size={size} color={color} />;
          },
          tabBarActiveTintColor: '#6200ee',
          tabBarInactiveTintColor: 'gray',
        })}
      >
        <Tab.Screen 
          name="Home" 
          component={HomeScreen} 
          options={{ title: 'Início' }}
        />
        <Tab.Screen 
          name="Jobs" 
          component={JobStack} 
          options={{ headerShown: false, title: 'Vagas' }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

export default AppNavigator;