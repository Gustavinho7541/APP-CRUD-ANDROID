// src/services/supabase.js
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://bybvmydtzikvapqohlmn.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJ5YnZteWR0emlrdmFwcW9obG1uIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQ2ODAxODEsImV4cCI6MjA3MDI1NjE4MX0.YLg5OPNSzG9mD-qPd5f3NWfKiouk-d7GxJ-oiN0c7B4';

// Validação das credenciais
const isValidUrl = (url) => {
  try {
    new URL(url);
    return true;
  } catch (error) {
    return false;
  }
};

let supabase;

if (supabaseUrl && supabaseKey && isValidUrl(supabaseUrl)) {
  try {
    supabase = createClient(supabaseUrl, supabaseKey);
    console.log('Supabase client initialized successfully');
  } catch (error) {
    console.error('Error creating Supabase client:', error);
    supabase = createMockClient();
  }
} else {
  console.warn('Invalid Supabase credentials. Using mock mode.');
  supabase = createMockClient();
}

// Função para criar cliente mock
function createMockClient() {
  return {
    from: (table) => ({
      select: () => ({
        order: () => Promise.resolve({ 
          data: [
            {
              id: 1,
              title: "Desenvolvedor Frontend",
              company: "Tech Solutions",
              location: "São Paulo, SP",
              salary: 5000,
              description: "Vaga para desenvolvedor React com experiência",
              created_at: new Date().toISOString()
            },
            {
              id: 2,
              title: "Designer UX/UI",
              company: "Creative Agency",
              location: "Remoto",
              salary: 4500,
              description: "Procuramos designer criativo para nossa equipe",
              created_at: new Date().toISOString()
            }
          ],
          error: null 
        })
      }),
      insert: (data) => Promise.resolve({ error: null }),
      update: (data) => Promise.resolve({ error: null }),
      delete: () => Promise.resolve({ error: null })
    })
  };
}

export { supabase };