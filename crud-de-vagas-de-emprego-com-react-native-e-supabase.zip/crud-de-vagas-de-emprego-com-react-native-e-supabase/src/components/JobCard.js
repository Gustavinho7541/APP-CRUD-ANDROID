// src/components/JobCard.js
import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { Card, Button } from 'react-native-paper';

const JobCard = ({ job, onEdit, onDelete, onViewDetails }) => {
  return (
    <Card style={styles.card}>
      <Card.Content>
        <Text style={styles.title}>{job.title}</Text>
        <Text style={styles.company}>{job.company}</Text>
        <Text style={styles.location}>{job.location}</Text>
        <Text style={styles.salary}>Salário: R$ {job.salary}</Text>
        <Text numberOfLines={2} style={styles.description}>
          {job.description}
        </Text>
      </Card.Content>
      <Card.Actions>
        <Button onPress={() => onViewDetails(job)}>Ver Detalhes</Button>
        <Button onPress={() => onEdit(job)}>Editar</Button>
        <Button onPress={() => onDelete(job.id)}>Excluir</Button>
      </Card.Actions>
    </Card>
  );
};

const styles = StyleSheet.create({
  card: {
    margin: 10,
    elevation: 3,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  company: {
    fontSize: 16,
    color: '#555',
  },
  location: {
    fontSize: 14,
    color: '#777',
  },
  salary: {
    fontSize: 14,
    color: '#2ecc71',
    fontWeight: 'bold',
  },
  description: {
    marginTop: 10,
    color: '#555',
  },
});

export default JobCard;
