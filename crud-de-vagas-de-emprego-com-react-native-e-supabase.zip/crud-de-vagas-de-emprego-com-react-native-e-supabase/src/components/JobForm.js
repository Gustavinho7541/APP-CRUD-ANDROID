// src/components/JobForm.js
import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';
import { TextInput, Button } from 'react-native-paper';

const JobForm = ({ onSubmit, initialData, buttonText }) => {
  const [title, setTitle] = useState(initialData?.title || '');
  const [company, setCompany] = useState(initialData?.company || '');
  const [location, setLocation] = useState(initialData?.location || '');
  const [salary, setSalary] = useState(initialData?.salary?.toString() || '');
  const [description, setDescription] = useState(initialData?.description || '');

  const handleSubmit = () => {
    const jobData = {
      title,
      company,
      location,
      salary: parseFloat(salary),
      description,
    };
    onSubmit(jobData);
  };

  return (
    <View style={styles.container}>
      <TextInput
        label="Título da Vaga"
        value={title}
        onChangeText={setTitle}
        style={styles.input}
      />
      <TextInput
        label="Empresa"
        value={company}
        onChangeText={setCompany}
        style={styles.input}
      />
      <TextInput
        label="Localização"
        value={location}
        onChangeText={setLocation}
        style={styles.input}
      />
      <TextInput
        label="Salário"
        value={salary}
        onChangeText={setSalary}
        keyboardType="numeric"
        style={styles.input}
      />
      <TextInput
        label="Descrição"
        value={description}
        onChangeText={setDescription}
        multiline
        numberOfLines={4}
        style={styles.input}
      />
      <Button mode="contained" onPress={handleSubmit} style={styles.button}>
        {buttonText}
      </Button>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  input: {
    marginBottom: 16,
  },
  button: {
    marginTop: 8,
  },
});

export default JobForm;