// src/screens/EditJobScreen.js
import React, { useState } from 'react';
import { Alert } from 'react-native';
import { supabase } from '../services/supabase';
import JobForm from '../components/JobForm';

const EditJobScreen = ({ route, navigation }) => {
  const { job } = route.params;
  const [isMock] = useState(typeof supabase.from !== 'function');

  const handleSubmit = async (jobData) => {
    try {
      if (isMock) {
        // Simula edição no modo mock
        Alert.alert('Sucesso', 'Vaga atualizada com sucesso! (Modo Demo)');
        navigation.goBack();
        return;
      }

      const { error } = await supabase
        .from('jobs')
        .update(jobData)
        .eq('id', job.id);

      if (error) throw error;
      
      Alert.alert('Sucesso', 'Vaga atualizada com sucesso!');
      navigation.goBack();
    } catch (error) {
      Alert.alert('Erro', error.message);
    }
  };

  return (
    <JobForm
      onSubmit={handleSubmit}
      initialData={job}
      buttonText="Atualizar Vaga"
    />
  );
};

export default EditJobScreen;