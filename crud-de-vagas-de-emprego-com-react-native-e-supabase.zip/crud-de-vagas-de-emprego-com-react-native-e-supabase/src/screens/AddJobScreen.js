// src/screens/AddJobScreen.js
import React, { useState } from 'react';
import { Alert } from 'react-native';
import { supabase } from '../services/supabase';
import JobForm from '../components/JobForm';

const AddJobScreen = ({ navigation }) => {
  const [isMock] = useState(typeof supabase.from !== 'function');

  const handleSubmit = async (jobData) => {
    try {
      if (isMock) {
        // Simula adição no modo mock
        Alert.alert('Sucesso', 'Vaga cadastrada com sucesso! (Modo Demo)');
        navigation.goBack();
        return;
      }

      const { error } = await supabase
        .from('jobs')
        .insert([jobData]);

      if (error) throw error;
      
      Alert.alert('Sucesso', 'Vaga cadastrada com sucesso!');
      navigation.goBack();
    } catch (error) {
      Alert.alert('Erro', error.message);
    }
  };

  return (
    <JobForm
      onSubmit={handleSubmit}
      buttonText="Cadastrar Vaga"
    />
  );
};

export default AddJobScreen;