// src/screens/JobListScreen.js
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, Alert, ActivityIndicator } from 'react-native';
import { FAB, Button } from 'react-native-paper';
import { supabase } from '../services/supabase';
import JobCard from '../components/JobCard';

const JobListScreen = ({ navigation }) => {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isMock, setIsMock] = useState(false);

  useEffect(() => {
    fetchJobs();
  }, []);

  const fetchJobs = async () => {
    try {
      setLoading(true);
      
      // Verifica se estamos usando o mock
      if (typeof supabase.from !== 'function') {
        setIsMock(true);
        // Dados mock para desenvolvimento
        setJobs([
          {
            id: 1,
            title: "Desenvolvedor Frontend",
            company: "Tech Solutions",
            location: "São Paulo, SP",
            salary: 5000,
            description: "Vaga para desenvolvedor React com experiência",
            created_at: new Date().toISOString()
          },
          {
            id: 2,
            title: "Designer UX/UI",
            company: "Creative Agency",
            location: "Remoto",
            salary: 4500,
            description: "Procuramos designer criativo para nossa equipe",
            created_at: new Date().toISOString()
          }
        ]);
        setLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from('jobs')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setJobs(data || []);
    } catch (error) {
      Alert.alert('Erro', error.message);
      // Fallback para dados mock em caso de erro
      setIsMock(true);
      setJobs([
        {
          id: 1,
          title: "Desenvolvedor Frontend",
          company: "Tech Solutions",
          location: "São Paulo, SP",
          salary: 5000,
          description: "Vaga para desenvolvedor React com experiência"
        },
        {
          id: 2,
          title: "Designer UX/UI",
          company: "Creative Agency",
          location: "Remoto",
          salary: 4500,
          description: "Procuramos designer criativo para nossa equipe"
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    Alert.alert(
      'Confirmar Exclusão',
      'Tem certeza que deseja excluir esta vaga?',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Excluir',
          style: 'destructive',
          onPress: async () => {
            try {
              if (isMock) {
                // Simula exclusão no modo mock
                setJobs(jobs.filter(job => job.id !== id));
                Alert.alert('Sucesso', 'Vaga excluída com sucesso! (Modo Demo)');
                return;
              }

              const { error } = await supabase
                .from('jobs')
                .delete()
                .eq('id', id);

              if (error) throw error;
              setJobs(jobs.filter(job => job.id !== id));
              Alert.alert('Sucesso', 'Vaga excluída com sucesso!');
            } catch (error) {
              Alert.alert('Erro', error.message);
            }
          },
        },
      ]
    );
  };

  const handleEdit = (job) => {
    navigation.navigate('EditJob', { job });
  };

  const handleViewDetails = (job) => {
    navigation.navigate('JobDetail', { job });
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#6200ee" />
        <Text>Carregando vagas...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Vagas de Emprego</Text>
      
      {isMock && (
        <View style={styles.warning}>
          <Text style={styles.warningText}>
            ⚠️ Modo Demo: Usando dados de exemplo
          </Text>
          <Button 
            mode="outlined" 
            onPress={() => Alert.alert(
              'Configurar Supabase',
              'Para usar com dados reais, configure suas credenciais do Supabase em src/services/supabase.js'
            )}
          >
            Configurar
          </Button>
        </View>
      )}
      
      {jobs.length === 0 ? (
        <View style={styles.center}>
          <Text>Nenhuma vaga cadastrada.</Text>
          <Button 
            mode="contained" 
            onPress={() => navigation.navigate('AddJob')}
            style={styles.addButton}
          >
            Adicionar Primeira Vaga
          </Button>
        </View>
      ) : (
        <FlatList
          data={jobs}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <JobCard
              job={item}
              onEdit={handleEdit}
              onDelete={handleDelete}
              onViewDetails={handleViewDetails}
            />
          )}
        />
      )}
      
      <FAB
        style={styles.fab}
        icon="plus"
        onPress={() => navigation.navigate('AddJob')}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 8,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    margin: 16,
    color: '#333',
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  warning: {
    backgroundColor: '#fff3cd',
    padding: 15,
    margin: 10,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ffeaa7',
  },
  warningText: {
    color: '#856404',
    textAlign: 'center',
    marginBottom: 10,
  },
  addButton: {
    marginTop: 20,
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
    backgroundColor: '#6200ee',
  },
});

export default JobListScreen;