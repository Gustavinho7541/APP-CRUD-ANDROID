// src/screens/HomeScreen.js
import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView } from 'react-native';
import { Button, Card } from 'react-native-paper';

const HomeScreen = ({ navigation }) => {
  return (
    <ScrollView contentContainerStyle={styles.scrollContainer}>
      <View style={styles.container}>
        <Image
          source={{
            uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQr6hNvv43GvoYqJZHVrTs1ySR-1Y6iAy5hJQ&s',
          }}
          style={styles.photo}
        />
        
        <Text style={styles.title}>Classificação de Empregos</Text>
        
        <Card style={styles.card}>
          <Text style={styles.paragraph1}>Empregos Formais</Text>
          <Text style={styles.paragraph2}>
            Trabalho Formal ou Assalariado: Vínculo empregatício com a empresa, 
            regido pela Consolidação das Leis do Trabalho (CLT), com direitos como 
            férias remuneradas, 13º salário e benefícios.
          </Text>
          <Button 
            mode="contained" 
            onPress={() => navigation.navigate('JobList')}
            style={styles.button}
          >
            Ver Vagas
          </Button>
        </Card>

        <Card style={styles.card}>
          <Text style={styles.paragraph1}>Cadastrar Nova Vaga</Text>
          <Text style={styles.paragraph2}>
            Adicione novas oportunidades de emprego para ajudar pessoas a 
            encontrarem seu próximo trabalho.
          </Text>
          <Button 
            mode="contained" 
            onPress={() => navigation.navigate('AddJob')}
            style={styles.button}
          >
            Adicionar Vaga
          </Button>
        </Card>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  scrollContainer: {
    paddingBottom: 20,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph1: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  paragraph2: {
    margin: 24,
    fontSize: 14,
    textAlign: 'center',
  },
  title: {
    margin: 24,
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  photo: {
    width: '100%',
    height: 200,
    resizeMode: 'cover',
  },
  card: {
    margin: 16,
    padding: 16,
    backgroundColor: '#fff',
    borderRadius: 10,
    elevation: 3,
  },
  button: {
    margin: 16,
  },
});

export default HomeScreen;